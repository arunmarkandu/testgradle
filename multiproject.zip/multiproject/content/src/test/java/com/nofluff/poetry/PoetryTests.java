package com.nofluff.poetry;

import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Before;
import java.util.List;

public class PoetryTests {
  Poetry pe;
  
}